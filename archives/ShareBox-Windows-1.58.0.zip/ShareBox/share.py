# -*- coding: utf-8 -*-
"""ShareBox 1.58.0 — запускалка.

Сама программа лежит рядом в закрытом виде (файлы sharebox-*.dat). Этот файл
только находит её, проверяет, что она цела и что Python подходит, и запускает.
Запуск такой же, как у обычной программы:  python share.py  /  pythonw share.py
"""
import glob
import hashlib
import json
import marshal
import os
import sys
import types
import zlib

MAGIC = b"ShareBoxCore1\n"


def stop(text):
    """Причина словами. Без консоли (pythonw) сообщения никто не увидит — окно."""
    sys.stderr = sys.stderr or sys.__stderr__
    try:
        if sys.stderr is None:
            raise OSError
        sys.stderr.write("ShareBox: " + text + "\n")
    except (OSError, ValueError):
        if os.name == "nt":
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, text, "ShareBox не запустился", 0x10)
            except Exception:
                pass
    raise SystemExit(1)


def load():
    here = os.path.dirname(os.path.abspath(__file__))
    tag = "%d.%d" % sys.version_info[:2]
    path = os.path.join(here, "sharebox-%s.dat" % tag)
    if not os.path.isfile(path):
        others = sorted(os.path.basename(one)[9:-4]
                        for one in glob.glob(os.path.join(here, "sharebox-*.dat")))
        if others:
            stop("Эта сборка ShareBox сделана для Python %s, а здесь работает "
                 "Python %s. Запускайте тем Python, который лежит в папке "
                 "ShareBox (папка python), или возьмите сборку под ваш Python."
                 % (", ".join(others), tag))
        stop("Рядом с share.py нет файла sharebox-%s.dat. Распакуйте архив "
             "целиком и не переносите share.py отдельно." % tag)
    try:
        with open(path, "rb") as handle:
            blob = handle.read()
        if not blob.startswith(MAGIC):
            raise ValueError
        head, _, body = blob[len(MAGIC):].partition(b"\n")
        meta = json.loads(head.decode("ascii"))
    except Exception:
        stop("Файл sharebox-%s.dat повреждён. Распакуйте архив заново." % tag)
    if hashlib.sha256(body).hexdigest() != meta.get("sha256") or meta.get("python") != tag:
        stop("Файл sharebox-%s.dat повреждён или собран для другого Python. "
             "Распакуйте архив заново." % tag)
    return marshal.loads(zlib.decompress(body))


def main():
    code = load()
    program = types.ModuleType("__main__")
    program.__file__ = os.path.abspath(__file__)
    sys.modules["__main__"] = program
    exec(code, program.__dict__)


main()
