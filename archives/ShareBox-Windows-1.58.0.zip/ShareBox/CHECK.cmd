@echo off
rem Проверка: почему телефон не пускает внутрь.
call "%~dp0ShareBox.cmd" --check
