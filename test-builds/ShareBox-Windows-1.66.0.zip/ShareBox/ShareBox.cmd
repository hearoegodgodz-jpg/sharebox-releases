@echo off
rem ShareBox — запуск. Python не нужен: он лежит рядом, в папке python.
chcp 65001 >nul
set PYTHONUTF8=1
title ShareBox
cd /d "%~dp0"

rem Самообновление сохраняет встроенный Python старой установки. В ней
rem ещё может не быть своего ShareBox.exe — используем прежний pythonw.exe.
set "SB_HOST=%~dp0python\ShareBox.exe"
if not exist "%SB_HOST%" set "SB_HOST=%~dp0python\pythonw.exe"
if not exist "%~dp0python\python.exe" goto missingpython
if not exist "%SB_HOST%" goto missingpython
goto ready

:missingpython
  echo.
  echo   Папка python рядом с этим файлом потерялась.
  echo   Распакуйте архив целиком и запустите снова.
  echo.
  pause
  exit /b 1

:ready

if not "%~1"=="" (
  rem служебный запуск (--autostart, --check): показать вывод и подождать
  echo.
  "%~dp0python\python.exe" "%~dp0share.py" %*
  echo.
  pause
  exit /b
)

rem Примерка с окном: если share.py не запускается вовсе (битый файл,
rem вырезанный антивирусом Python), ShareBox.exe умрёт молча и человек увидит
rem только мелькнувшую консоль. Здесь же причина остаётся на экране.
"%~dp0python\python.exe" "%~dp0share.py" --version >nul 2>"%TEMP%\sharebox-start.txt"
if errorlevel 1 (
  echo.
  echo   ShareBox не запускается. Причина:
  echo.
  type "%TEMP%\sharebox-start.txt"
  echo.
  pause
  exit /b 1
)
del "%TEMP%\sharebox-start.txt" >nul 2>&1

rem Обычный запуск — без чёрного окна: ShareBox.exe (тот же встроенный Python
rem под своим именем и значком) работает молча, а пульт открывается в
rem браузере. Остановить можно кнопкой на самом пульте.
start "" "%SB_HOST%" "%~dp0share.py"
